/****** Variables Globales******/

//Récupération de l'input "Email"
const inputEmail = document.querySelector("#email");
// Récupération de l'input "Password"
const inputPassword = document.querySelector("#password");
// Récupération de l'input "Submit"
const inputSubmit = document.querySelector("#btn-login");

/****** Les Fonctions******/

// Gestion de la connexion
function login() {
  // contacte de l'api.
  const apiUrl = "http://localhost:5678/api/users/login";
  // les données transmises à l'api.
  // const data = {
  //   username: inputEmail.value,
  //   password: inputPassword.value,
  //   //Utilisation de ".value", pour obtenir la valeur de l'input.
  // };
  const email = inputEmail.value;
  const password = inputPassword.value;

  //Configuration de requête HTTP
  const requestOptions = {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ email, password }),
  };

  //Appel de l'API
  fetch(apiUrl, requestOptions)
    .then((response) => {
      if (!response.ok) {
        throw new Error(
          "Les informations utilisateur/mot de passe ne sont  pas correctes"
        );
      }
      // Demande à avoir un retour de la réponse JSON pour le traitement dans le prochain bloc then.
      return response.json();
    })

    .then((authUser) => {
      console.log("authUser", authUser);
      //Stockage de L'ID et du token de l'utilisateur.
      const userId = authUser.usersId;
      const authToken = authUser.token;
      localStorage.setItem("userId", userId);
      localStorage.setItem("authToken", authToken);

      //Affichage des informations récupérées via la console.
      console.log("userId", userId);
      console.log("authToken", authToken);

      // Si les informations transmises sont correcte on redire vers la page d'accueil du site.
      // window.location.href = "../index.html";
    })

    .catch((error) => {
      //Affichage d'un message d'erreur
      alert(
        "Erreur de connexion, merci de vérifier vos identifiants de connexion."
      );
    });
}

/******Gestionnaire d'événements ******/
inputSubmit.addEventListener("click", login);
